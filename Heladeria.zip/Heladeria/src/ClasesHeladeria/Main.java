/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesHeladeria;

import ClasesHeladeria.ConexionDB;
import ClasesHeladeria.Usuario;

public class Main {
    public static void main(String[] args) {

        System.out.println("===== PRUEBA DE CONEXIÓN Y LECTURA =====");

        ConexionDB.conectar();

        System.out.println("\n--- LISTADO DE USUARIOS ---");
        for (Usuario u : Usuario.listarUsuarios()) {
            System.out.println("ID: " + u.getIdUsuario()
                    + " | Nombre: " + u.getNombre()
                    + " | Cargo: " + u.getCargo()
                    + " | Usuario: " + u.getUsuario());
        }

        ConexionDB.desconectar();

        System.out.println("\n===== FIN DE LA PRUEBA =====");
    }
}
