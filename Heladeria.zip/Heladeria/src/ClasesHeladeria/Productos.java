/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesHeladeria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Productos {
    private int idProducto;
    private String nombre;
    private String tipoDeProducto;
    private double precio;
    private int cantidad;

    public Productos() {}

    public Productos(int idProducto, String nombre, String tipoDeProducto, double precio, int cantidad) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.tipoDeProducto = tipoDeProducto;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipoDeProducto() { return tipoDeProducto; }
    public void setTipoDeProducto(String tipoDeProducto) { this.tipoDeProducto = tipoDeProducto; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    
    // CRUD
    
    public boolean agregarProducto() {
        String sql = "INSERT INTO Productos(nombre, tipoDeProducto, precio, cantidad) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, tipoDeProducto);
            stmt.setDouble(3, precio);
            stmt.setInt(4, cantidad);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al agregar producto: " + e.getMessage());
            return false;
        }
    }

    public static List<Productos> listarProductos() {
        List<Productos> lista = new ArrayList<>();
        String sql = "SELECT * FROM Productos";
        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Productos p = new Productos(
                        rs.getInt("idProducto"),
                        rs.getString("nombre"),
                        rs.getString("tipoDeProducto"),
                        rs.getDouble("precio"),
                        rs.getInt("cantidad")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar productos: " + e.getMessage());
        }
        return lista;
    }

    public boolean actualizarProducto() {
        String sql = "UPDATE Productos SET nombre=?, tipoDeProducto=?, precio=?, cantidad=? WHERE idProducto=?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, tipoDeProducto);
            stmt.setDouble(3, precio);
            stmt.setInt(4, cantidad);
            stmt.setInt(5, idProducto);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarProducto() {
        String sql = "DELETE FROM Productos WHERE idProducto=?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idProducto);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }
}
