/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesHeladeria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Ventas {
    private int idVenta;
    private String fecha;
    private int idUsuario;
    private int cantidad;
    private double subtotal;

    public Ventas() {}

    public Ventas(int idVenta, String fecha, int idUsuario, int cantidad, double subtotal) {
        this.idVenta = idVenta;
        this.fecha = fecha;
        this.idUsuario = idUsuario;
        this.cantidad = cantidad;
        this.subtotal = subtotal;
    }

    public int getIdVenta() { return idVenta; }
    public void setIdVenta(int idVenta) { this.idVenta = idVenta; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    
    // CRUD
    
    public boolean agregarVenta() {
        String sql = "INSERT INTO Ventas(fecha, idUsuario, cantidad, subtotal) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, fecha);
            stmt.setInt(2, idUsuario);
            stmt.setInt(3, cantidad);
            stmt.setDouble(4, subtotal);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al agregar venta: " + e.getMessage());
            return false;
        }
    }

    public static List<Ventas> listarVentas() {
        List<Ventas> lista = new ArrayList<>();
        String sql = "SELECT * FROM Ventas";
        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Ventas v = new Ventas(
                        rs.getInt("idVenta"),
                        rs.getString("fecha"),
                        rs.getInt("idUsuario"),
                        rs.getInt("cantidad"),
                        rs.getDouble("subtotal")
                );
                lista.add(v);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar ventas: " + e.getMessage());
        }
        return lista;
    }

    public boolean actualizarVenta() {
        String sql = "UPDATE Ventas SET fecha=?, idUsuario=?, cantidad=?, subtotal=? WHERE idVenta=?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, fecha);
            stmt.setInt(2, idUsuario);
            stmt.setInt(3, cantidad);
            stmt.setDouble(4, subtotal);
            stmt.setInt(5, idVenta);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al actualizar venta: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarVenta() {
        String sql = "DELETE FROM Ventas WHERE idVenta=?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idVenta);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al eliminar venta: " + e.getMessage());
            return false;
        }
    }
}
